import { useState, useEffect, useCallback } from 'react';
import Sidebar from './components/Sidebar';
import TitleBar from './components/TitleBar';
import CommandBar from './components/CommandBar';
import Dashboard from './pages/Dashboard';
import Tasks from './pages/Tasks';
import Files from './pages/Files';
import Settings from './pages/Settings';
import styles from './App.module.css';

// Mock API when running outside Electron (browser dev)
const api = window.electronAPI || {
  tasks: {
    getAll: async () => mockTasks,
    create: async (t) => ({ ...t, id: Date.now().toString(), created_at: new Date().toISOString() }),
    update: async (id, u) => ({ id, ...u }),
    delete: async () => ({ success: true }),
  },
  ai: { command: async (cmd) => ({ type: 'unknown', message: 'Running outside Electron — AI commands require the desktop app.' }) },
  files: { list: async () => ({ items: [] }), pickDirectory: async () => null, open: async () => {}, organize: async () => ({}) },
  settings: { get: async () => null, set: async () => {} },
  sync: { status: async () => ({ connected: false }), connect: async () => ({}) },
  platform: 'web',
};

const mockTasks = [
  { id: '1', title: 'Review Q3 report', description: 'Check financials and KPIs', status: 'todo', priority: 'high', due_date: '2026-03-20', tags: ['finance'], created_at: new Date().toISOString() },
  { id: '2', title: 'Design system update', description: 'Update color tokens and component library', status: 'in-progress', priority: 'medium', due_date: null, tags: ['design'], created_at: new Date().toISOString() },
  { id: '3', title: 'Team standup notes', description: '', status: 'done', priority: 'low', due_date: null, tags: ['meetings'], created_at: new Date().toISOString() },
];

export default function App() {
  const [view, setView] = useState('dashboard');
  const [tasks, setTasks] = useState([]);
  const [cmdOpen, setCmdOpen] = useState(false);
  const [notification, setNotification] = useState(null);

  useEffect(() => {
    api.tasks.getAll().then(setTasks).catch(() => setTasks(mockTasks));
  }, []);

  // Global keyboard shortcut: Cmd/Ctrl+K opens command bar
  useEffect(() => {
    const handler = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setCmdOpen(v => !v);
      }
      if (e.key === 'Escape') setCmdOpen(false);
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  const notify = useCallback((msg, type = 'success') => {
    setNotification({ msg, type });
    setTimeout(() => setNotification(null), 3000);
  }, []);

  const handleAIAction = useCallback(async (action) => {
    if (action.error) { notify(action.error, 'error'); return; }
    switch (action.type) {
      case 'create_task': {
        const t = await api.tasks.create(action);
        setTasks(prev => [t, ...prev]);
        notify(`Task "${t.title}" created`);
        setView('tasks');
        break;
      }
      case 'update_task': {
        const t = await api.tasks.update(action.id, action.updates);
        setTasks(prev => prev.map(x => x.id === action.id ? { ...x, ...action.updates } : x));
        notify('Task updated');
        break;
      }
      case 'delete_task': {
        await api.tasks.delete(action.id);
        setTasks(prev => prev.filter(x => x.id !== action.id));
        notify('Task deleted');
        break;
      }
      case 'filter_tasks':
        setView('tasks');
        notify('Showing filtered tasks');
        break;
      case 'organize_files':
        setView('files');
        notify('Navigate to Files to organize');
        break;
      case 'show_stats':
        setView('dashboard');
        break;
      default:
        notify(action.message || 'Command processed', 'info');
    }
  }, [notify]);

  const pages = { dashboard: Dashboard, tasks: Tasks, files: Files, settings: Settings };
  const PageComponent = pages[view] || Dashboard;

  return (
    <div className={styles.app}>
      <TitleBar />
      <div className={styles.body}>
        <Sidebar view={view} setView={setView} tasks={tasks} />
        <main className={styles.main}>
          <PageComponent
            tasks={tasks}
            setTasks={setTasks}
            api={api}
            notify={notify}
            onOpenCmd={() => setCmdOpen(true)}
          />
        </main>
      </div>

      {cmdOpen && (
        <CommandBar
          onClose={() => setCmdOpen(false)}
          onAction={handleAIAction}
          api={api}
          context={{ taskCount: tasks.length, view }}
        />
      )}

      {notification && (
        <div className={`${styles.notification} ${styles[notification.type]} fade-in`}>
          <span>{notification.type === 'error' ? '✕' : notification.type === 'info' ? 'ℹ' : '✓'}</span>
          {notification.msg}
        </div>
      )}
    </div>
  );
}
