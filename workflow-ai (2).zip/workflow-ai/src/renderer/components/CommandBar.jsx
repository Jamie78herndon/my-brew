import { useState, useRef, useEffect } from 'react';
import styles from './CommandBar.module.css';

const EXAMPLES = [
  'Add a task to review the Q3 report by Friday, high priority',
  'Show me all in-progress tasks',
  'Create a task for team standup tomorrow',
  'Organize my Downloads folder by file type',
  'Show my productivity stats',
];

export default function CommandBar({ onClose, onAction, api, context }) {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [hint, setHint] = useState(0);
  const inputRef = useRef(null);

  useEffect(() => {
    inputRef.current?.focus();
    const t = setInterval(() => setHint(h => (h + 1) % EXAMPLES.length), 3000);
    return () => clearInterval(t);
  }, []);

  const handleSubmit = async () => {
    if (!input.trim() || loading) return;
    setLoading(true);
    setResult(null);
    const action = await api.ai.command(input.trim(), context);
    setLoading(false);
    setResult(action);
    if (!action.error) {
      setTimeout(() => {
        onAction(action);
        onClose();
      }, 800);
    }
  };

  const handleKey = (e) => {
    if (e.key === 'Enter') handleSubmit();
    if (e.key === 'Escape') onClose();
  };

  return (
    <div className={styles.overlay} onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className={styles.panel + ' fade-in'}>
        <div className={styles.header}>
          <span className={styles.aiDot} />
          <span className={styles.headerLabel}>AI Command</span>
          <kbd className={styles.esc} onClick={onClose}>esc</kbd>
        </div>

        <div className={styles.inputRow}>
          <span className={styles.prompt}>›</span>
          <input
            ref={inputRef}
            className={styles.input}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKey}
            placeholder={EXAMPLES[hint]}
            disabled={loading}
          />
          <button
            className={`${styles.run} ${loading ? styles.running : ''}`}
            onClick={handleSubmit}
            disabled={!input.trim() || loading}
          >
            {loading ? <span className={styles.spinner} /> : 'Run'}
          </button>
        </div>

        {result && (
          <div className={`${styles.result} ${result.error ? styles.error : styles.success} fade-in`}>
            {result.error
              ? <><span>✕</span> {result.error}</>
              : <><span>✓</span> Action: <strong>{result.type?.replace(/_/g, ' ')}</strong>{result.title ? ` — "${result.title}"` : ''}</>
            }
          </div>
        )}

        {!result && (
          <div className={styles.suggestions}>
            <span className={styles.sugLabel}>Try:</span>
            {EXAMPLES.slice(0, 3).map((ex, i) => (
              <button key={i} className={styles.sug} onClick={() => setInput(ex)}>
                {ex}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
