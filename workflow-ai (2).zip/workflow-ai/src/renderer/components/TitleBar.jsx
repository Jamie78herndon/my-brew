import styles from './TitleBar.module.css';

export default function TitleBar() {
  return (
    <div className={styles.titlebar}>
      <div className={styles.drag} />
      <span className={styles.title}>WorkFlow AI</span>
    </div>
  );
}
