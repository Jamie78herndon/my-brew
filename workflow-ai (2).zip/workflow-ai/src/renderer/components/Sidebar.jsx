import styles from './Sidebar.module.css';

const NAV = [
  { id: 'dashboard', label: 'Dashboard', icon: '⬡' },
  { id: 'tasks',     label: 'Tasks',     icon: '◈' },
  { id: 'files',     label: 'Files',     icon: '◫' },
];

const BOTTOM = [
  { id: 'settings', label: 'Settings', icon: '⚙' },
];

export default function Sidebar({ view, setView, tasks }) {
  const todoCount = tasks.filter(t => t.status === 'todo').length;
  const inProgressCount = tasks.filter(t => t.status === 'in-progress').length;

  return (
    <aside className={styles.sidebar}>
      <div className={styles.brand}>
        <div className={styles.logo}>W</div>
        <span className={styles.brandName}>WorkFlow</span>
      </div>

      <nav className={styles.nav}>
        {NAV.map(item => (
          <button
            key={item.id}
            className={`${styles.item} ${view === item.id ? styles.active : ''}`}
            onClick={() => setView(item.id)}
          >
            <span className={styles.icon}>{item.icon}</span>
            <span className={styles.label}>{item.label}</span>
            {item.id === 'tasks' && (todoCount + inProgressCount) > 0 && (
              <span className={styles.badge}>{todoCount + inProgressCount}</span>
            )}
          </button>
        ))}
      </nav>

      <div className={styles.divider} />

      <div className={styles.cmdHint} onClick={() => {
        window.dispatchEvent(new KeyboardEvent('keydown', { key: 'k', metaKey: true, bubbles: true }));
      }}>
        <span className={styles.cmdIcon}>⌘</span>
        <span>AI Command</span>
        <kbd>K</kbd>
      </div>

      <div className={styles.spacer} />

      {BOTTOM.map(item => (
        <button
          key={item.id}
          className={`${styles.item} ${view === item.id ? styles.active : ''}`}
          onClick={() => setView(item.id)}
        >
          <span className={styles.icon}>{item.icon}</span>
          <span className={styles.label}>{item.label}</span>
        </button>
      ))}
    </aside>
  );
}
