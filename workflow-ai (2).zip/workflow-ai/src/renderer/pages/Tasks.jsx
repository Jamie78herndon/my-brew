import { useState, useMemo } from 'react';
import styles from './Tasks.module.css';

const STATUSES = [
  { id: 'todo',        label: 'To Do',       color: 'var(--text-muted)' },
  { id: 'in-progress', label: 'In Progress',  color: 'var(--blue)' },
  { id: 'done',        label: 'Done',         color: 'var(--green)' },
];

const PRIORITIES = ['low', 'medium', 'high'];
const PRIORITY_COLOR = { high: 'var(--red)', medium: 'var(--amber)', low: 'var(--green)' };

function TaskCard({ task, onUpdate, onDelete }) {
  const [dragging, setDragging] = useState(false);
  const overdue = task.due_date && task.status !== 'done' && new Date(task.due_date) < new Date();

  return (
    <div
      className={`${styles.card} ${dragging ? styles.dragging : ''}`}
      draggable
      onDragStart={e => {
        e.dataTransfer.setData('taskId', task.id);
        setDragging(true);
      }}
      onDragEnd={() => setDragging(false)}
    >
      <div className={styles.cardTop}>
        <span className={styles.cardTitle}>{task.title}</span>
        <button className={styles.deleteBtn} onClick={() => onDelete(task.id)} title="Delete">✕</button>
      </div>

      {task.description && (
        <p className={styles.cardDesc}>{task.description}</p>
      )}

      <div className={styles.cardMeta}>
        <select
          className={styles.prioritySelect}
          value={task.priority}
          style={{ color: PRIORITY_COLOR[task.priority] }}
          onChange={e => onUpdate(task.id, { priority: e.target.value })}
        >
          {PRIORITIES.map(p => (
            <option key={p} value={p}>{p}</option>
          ))}
        </select>

        {task.due_date && (
          <span className={`${styles.dueDate} ${overdue ? styles.overdue : ''}`}>
            {overdue ? '⚠ ' : '◷ '}
            {new Date(task.due_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
          </span>
        )}
      </div>

      {task.tags?.length > 0 && (
        <div className={styles.tags}>
          {task.tags.map(tag => <span key={tag} className={styles.tag}>{tag}</span>)}
        </div>
      )}
    </div>
  );
}

function Column({ status, tasks, onUpdate, onDelete }) {
  const [over, setOver] = useState(false);

  return (
    <div
      className={`${styles.column} ${over ? styles.over : ''}`}
      onDragOver={e => { e.preventDefault(); setOver(true); }}
      onDragLeave={() => setOver(false)}
      onDrop={e => {
        e.preventDefault();
        setOver(false);
        const id = e.dataTransfer.getData('taskId');
        if (id) onUpdate(id, { status: status.id });
      }}
    >
      <div className={styles.colHeader}>
        <span className={styles.colDot} style={{ background: status.color }} />
        <span className={styles.colLabel}>{status.label}</span>
        <span className={styles.colCount}>{tasks.length}</span>
      </div>

      <div className={styles.cardList}>
        {tasks.map(task => (
          <TaskCard key={task.id} task={task} onUpdate={onUpdate} onDelete={onDelete} />
        ))}
        {tasks.length === 0 && (
          <div className={styles.emptyCol}>Drop tasks here</div>
        )}
      </div>
    </div>
  );
}

function NewTaskModal({ onSave, onClose }) {
  const [form, setForm] = useState({ title: '', description: '', priority: 'medium', due_date: '', tags: '' });

  const handle = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const submit = () => {
    if (!form.title.trim()) return;
    onSave({
      title: form.title.trim(),
      description: form.description.trim(),
      priority: form.priority,
      due_date: form.due_date || null,
      tags: form.tags ? form.tags.split(',').map(t => t.trim()).filter(Boolean) : [],
      status: 'todo',
    });
    onClose();
  };

  return (
    <div className={styles.modalOverlay} onClick={e => e.target === e.currentTarget && onClose()}>
      <div className={styles.modal + ' fade-in'}>
        <div className={styles.modalHeader}>
          <h2 className={styles.modalTitle}>New task</h2>
          <button className={styles.modalClose} onClick={onClose}>✕</button>
        </div>

        <div className={styles.field}>
          <label className={styles.fieldLabel}>Title</label>
          <input
            autoFocus
            className={styles.fieldInput}
            placeholder="What needs to be done?"
            value={form.title}
            onChange={e => handle('title', e.target.value)}
            onKeyDown={e => e.key === 'Enter' && submit()}
          />
        </div>

        <div className={styles.field}>
          <label className={styles.fieldLabel}>Description</label>
          <textarea
            className={`${styles.fieldInput} ${styles.textarea}`}
            placeholder="Optional details..."
            value={form.description}
            onChange={e => handle('description', e.target.value)}
            rows={3}
          />
        </div>

        <div className={styles.fieldRow}>
          <div className={styles.field}>
            <label className={styles.fieldLabel}>Priority</label>
            <select className={styles.fieldInput} value={form.priority} onChange={e => handle('priority', e.target.value)}>
              {PRIORITIES.map(p => <option key={p} value={p}>{p}</option>)}
            </select>
          </div>
          <div className={styles.field}>
            <label className={styles.fieldLabel}>Due date</label>
            <input type="date" className={styles.fieldInput} value={form.due_date} onChange={e => handle('due_date', e.target.value)} />
          </div>
        </div>

        <div className={styles.field}>
          <label className={styles.fieldLabel}>Tags (comma-separated)</label>
          <input
            className={styles.fieldInput}
            placeholder="design, urgent, review"
            value={form.tags}
            onChange={e => handle('tags', e.target.value)}
          />
        </div>

        <div className={styles.modalActions}>
          <button className={styles.cancelBtn} onClick={onClose}>Cancel</button>
          <button className={styles.saveBtn} onClick={submit} disabled={!form.title.trim()}>Create task</button>
        </div>
      </div>
    </div>
  );
}

export default function Tasks({ tasks, setTasks, api, notify, onOpenCmd }) {
  const [showModal, setShowModal] = useState(false);
  const [search, setSearch] = useState('');
  const [filterPriority, setFilterPriority] = useState('all');

  const filtered = useMemo(() => {
    return tasks.filter(t => {
      const matchSearch = !search || t.title.toLowerCase().includes(search.toLowerCase());
      const matchPri = filterPriority === 'all' || t.priority === filterPriority;
      return matchSearch && matchPri;
    });
  }, [tasks, search, filterPriority]);

  const byStatus = useMemo(() => {
    const map = {};
    STATUSES.forEach(s => { map[s.id] = filtered.filter(t => t.status === s.id); });
    return map;
  }, [filtered]);

  const handleCreate = async (task) => {
    const created = await api.tasks.create(task);
    setTasks(prev => [created, ...prev]);
    notify(`Task "${created.title}" created`);
  };

  const handleUpdate = async (id, updates) => {
    await api.tasks.update(id, updates);
    setTasks(prev => prev.map(t => t.id === id ? { ...t, ...updates } : t));
  };

  const handleDelete = async (id) => {
    await api.tasks.delete(id);
    setTasks(prev => prev.filter(t => t.id !== id));
    notify('Task deleted');
  };

  return (
    <div className={styles.page}>
      <div className={styles.topRow}>
        <div>
          <h1 className={styles.heading}>Tasks</h1>
          <p className={styles.sub}>{tasks.length} total · drag cards to update status</p>
        </div>
        <div className={styles.actions}>
          <button className={styles.aiBtn} onClick={onOpenCmd}>⌘ AI</button>
          <button className={styles.newBtn} onClick={() => setShowModal(true)}>+ New task</button>
        </div>
      </div>

      <div className={styles.filterRow}>
        <input
          className={styles.search}
          placeholder="Search tasks..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        <div className={styles.priorityFilter}>
          {['all', ...PRIORITIES].map(p => (
            <button
              key={p}
              className={`${styles.filterBtn} ${filterPriority === p ? styles.filterActive : ''}`}
              onClick={() => setFilterPriority(p)}
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      <div className={styles.board}>
        {STATUSES.map(status => (
          <Column
            key={status.id}
            status={status}
            tasks={byStatus[status.id] || []}
            onUpdate={handleUpdate}
            onDelete={handleDelete}
          />
        ))}
      </div>

      {showModal && <NewTaskModal onSave={handleCreate} onClose={() => setShowModal(false)} />}
    </div>
  );
}
