import { useState, useEffect } from 'react';
import styles from './Files.module.css';

const TYPE_ICON = {
  folder: '◫', Images: '◉', Documents: '◈', Spreadsheets: '▦',
  Videos: '▷', Audio: '♫', Code: '◌', Archives: '⊞',
  Presentations: '◧', Other: '·',
};

const TYPE_COLOR = {
  folder: 'var(--text-secondary)', Images: 'var(--blue)', Documents: 'var(--accent-light)',
  Spreadsheets: 'var(--green)', Videos: 'var(--red)', Audio: 'var(--amber)',
  Code: 'var(--blue)', Archives: 'var(--amber)', Other: 'var(--text-muted)',
};

function formatSize(bytes) {
  if (!bytes) return '';
  if (bytes < 1024) return `${bytes}B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)}KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)}MB`;
}

export default function Files({ api, notify }) {
  const [dir, setDir] = useState(null);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [organizing, setOrganizing] = useState(false);
  const [viewMode, setViewMode] = useState('grid'); // grid | list
  const [filter, setFilter] = useState('all');

  const loadDir = async (path) => {
    if (!path) return;
    setLoading(true);
    const result = await api.files.list(path);
    setLoading(false);
    if (result.error) { notify(result.error, 'error'); return; }
    setDir(path);
    setItems(result.items || []);
  };

  const pickDir = async () => {
    const path = await api.files.pickDirectory();
    if (path) loadDir(path);
  };

  const openItem = (item) => {
    if (item.isDirectory) loadDir(item.path);
    else api.files.open(item.path);
  };

  const organize = async (strategy) => {
    if (!dir) return;
    setOrganizing(true);
    const result = await api.files.organize(dir, strategy);
    setOrganizing(false);
    if (result.error) { notify(result.error, 'error'); return; }
    notify(`Organized ${result.moved} files by ${strategy.replace('_', ' ')}`);
    loadDir(dir);
  };

  const types = ['all', ...new Set(items.filter(i => !i.isDirectory).map(i => i.type))];
  const filtered = filter === 'all' ? items : items.filter(i => i.isDirectory || i.type === filter);

  return (
    <div className={styles.page}>
      <div className={styles.topRow}>
        <div>
          <h1 className={styles.heading}>Files</h1>
          <p className={styles.sub}>{dir ? dir : 'No folder selected'}</p>
        </div>
        <div className={styles.actions}>
          {dir && (
            <>
              <div className={styles.organizeGroup}>
                <span className={styles.organizeLabel}>Organize:</span>
                <button className={styles.orgBtn} onClick={() => organize('by_type')} disabled={organizing}>by type</button>
                <button className={styles.orgBtn} onClick={() => organize('by_date')} disabled={organizing}>by date</button>
              </div>
              <div className={styles.viewToggle}>
                <button className={`${styles.viewBtn} ${viewMode === 'grid' ? styles.viewActive : ''}`} onClick={() => setViewMode('grid')}>⊞</button>
                <button className={`${styles.viewBtn} ${viewMode === 'list' ? styles.viewActive : ''}`} onClick={() => setViewMode('list')}>≡</button>
              </div>
            </>
          )}
          <button className={styles.pickBtn} onClick={pickDir}>
            {dir ? '↺ Change folder' : '+ Open folder'}
          </button>
        </div>
      </div>

      {dir && (
        <div className={styles.typeFilter}>
          {types.map(t => (
            <button
              key={t}
              className={`${styles.typeBtn} ${filter === t ? styles.typeActive : ''}`}
              onClick={() => setFilter(t)}
            >
              {t !== 'all' && <span style={{ color: TYPE_COLOR[t] }}>{TYPE_ICON[t]} </span>}
              {t}
            </button>
          ))}
        </div>
      )}

      {!dir && (
        <div className={styles.empty}>
          <div className={styles.emptyIcon}>◫</div>
          <p className={styles.emptyTitle}>No folder open</p>
          <p className={styles.emptySub}>Open a folder to browse and manage your files</p>
          <button className={styles.emptyBtn} onClick={pickDir}>Open folder</button>
        </div>
      )}

      {loading && (
        <div className={styles.loading}>
          <span className={styles.spinner} />
          Loading...
        </div>
      )}

      {!loading && dir && (
        <div className={viewMode === 'grid' ? styles.grid : styles.list}>
          {filtered.map(item => (
            <div
              key={item.path}
              className={viewMode === 'grid' ? styles.gridItem : styles.listItem}
              onDoubleClick={() => openItem(item)}
              title={item.name}
            >
              <span
                className={styles.itemIcon}
                style={{ color: TYPE_COLOR[item.type] || 'var(--text-muted)' }}
              >
                {TYPE_ICON[item.type] || '·'}
              </span>
              <span className={styles.itemName}>{item.name}</span>
              {viewMode === 'list' && (
                <>
                  <span className={styles.itemType}>{item.type}</span>
                  <span className={styles.itemSize}>{formatSize(item.size)}</span>
                  <span className={styles.itemDate}>
                    {item.modified ? new Date(item.modified).toLocaleDateString() : ''}
                  </span>
                </>
              )}
            </div>
          ))}
          {filtered.length === 0 && !loading && (
            <div className={styles.emptyFilter}>No files match this filter</div>
          )}
        </div>
      )}
    </div>
  );
}
