import { useState, useEffect } from 'react';
import styles from './Settings.module.css';

function Section({ title, children }) {
  return (
    <div className={styles.section}>
      <h2 className={styles.sectionTitle}>{title}</h2>
      {children}
    </div>
  );
}

function Row({ label, desc, children }) {
  return (
    <div className={styles.row}>
      <div className={styles.rowInfo}>
        <span className={styles.rowLabel}>{label}</span>
        {desc && <span className={styles.rowDesc}>{desc}</span>}
      </div>
      <div className={styles.rowControl}>{children}</div>
    </div>
  );
}

export default function Settings({ api, notify }) {
  const [apiKey, setApiKey] = useState('');
  const [showKey, setShowKey] = useState(false);
  const [syncStatus, setSyncStatus] = useState({ connected: false, provider: null, lastSync: null });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api.settings.get('anthropic_api_key').then(k => { if (k) setApiKey(k); });
    api.sync.status().then(setSyncStatus);
  }, []);

  const saveApiKey = async () => {
    setSaving(true);
    await api.settings.set('anthropic_api_key', apiKey.trim());
    setSaving(false);
    notify('API key saved');
  };

  const connectSync = async (provider) => {
    const result = await api.sync.connect(provider);
    if (result.success) {
      setSyncStatus({ connected: true, provider, lastSync: new Date().toISOString() });
      notify(`Connected to ${provider}`);
    }
  };

  return (
    <div className={styles.page}>
      <div className={styles.topRow}>
        <h1 className={styles.heading}>Settings</h1>
        <p className={styles.sub}>Configure your WorkFlow AI experience</p>
      </div>

      <div className={styles.content}>
        {/* AI */}
        <Section title="AI Configuration">
          <Row
            label="Anthropic API Key"
            desc="Required for natural language commands. Get yours at console.anthropic.com"
          >
            <div className={styles.apiKeyRow}>
              <input
                type={showKey ? 'text' : 'password'}
                className={styles.input}
                placeholder="sk-ant-..."
                value={apiKey}
                onChange={e => setApiKey(e.target.value)}
              />
              <button className={styles.showBtn} onClick={() => setShowKey(v => !v)}>
                {showKey ? 'hide' : 'show'}
              </button>
              <button className={styles.saveBtn} onClick={saveApiKey} disabled={!apiKey.trim() || saving}>
                {saving ? 'Saving…' : 'Save'}
              </button>
            </div>
          </Row>
          <Row
            label="AI Model"
            desc="The Claude model used for natural language commands"
          >
            <select className={styles.select} defaultValue="claude-sonnet-4-20250514">
              <option value="claude-sonnet-4-20250514">Claude Sonnet 4 (recommended)</option>
              <option value="claude-opus-4-20250514">Claude Opus 4 (most capable)</option>
              <option value="claude-haiku-4-5-20251001">Claude Haiku 4.5 (fastest)</option>
            </select>
          </Row>
        </Section>

        {/* Sync */}
        <Section title="Cloud Sync">
          <Row
            label="Sync provider"
            desc={syncStatus.connected
              ? `Connected to ${syncStatus.provider}${syncStatus.lastSync ? ` · Last synced ${new Date(syncStatus.lastSync).toLocaleString()}` : ''}`
              : 'Connect a cloud provider to sync your tasks across devices'}
          >
            <div className={styles.syncBtns}>
              <button
                className={`${styles.syncBtn} ${syncStatus.provider === 'google-drive' ? styles.syncActive : ''}`}
                onClick={() => connectSync('google-drive')}
              >
                Google Drive
              </button>
              <button
                className={`${styles.syncBtn} ${syncStatus.provider === 'dropbox' ? styles.syncActive : ''}`}
                onClick={() => connectSync('dropbox')}
              >
                Dropbox
              </button>
            </div>
          </Row>
        </Section>

        {/* About */}
        <Section title="About">
          <Row label="Version" desc="WorkFlow AI desktop app">
            <span className={styles.mono}>1.0.0</span>
          </Row>
          <Row label="Built with" desc="">
            <span className={styles.mono}>Electron · React · SQLite · Claude API</span>
          </Row>
        </Section>
      </div>
    </div>
  );
}
