import { useMemo } from 'react';
import styles from './Dashboard.module.css';

const PRIORITY_COLOR = { high: 'var(--red)', medium: 'var(--amber)', low: 'var(--green)' };
const STATUS_COLOR   = { todo: 'var(--text-muted)', 'in-progress': 'var(--blue)', done: 'var(--green)' };

function StatCard({ label, value, sub, color }) {
  return (
    <div className={styles.statCard}>
      <div className={styles.statValue} style={{ color }}>{value}</div>
      <div className={styles.statLabel}>{label}</div>
      {sub && <div className={styles.statSub}>{sub}</div>}
    </div>
  );
}

function MiniBar({ label, count, total, color }) {
  const pct = total ? Math.round((count / total) * 100) : 0;
  return (
    <div className={styles.miniBar}>
      <div className={styles.miniBarTop}>
        <span className={styles.miniBarLabel}>{label}</span>
        <span className={styles.miniBarCount}>{count}</span>
      </div>
      <div className={styles.miniBarTrack}>
        <div className={styles.miniBarFill} style={{ width: `${pct}%`, background: color }} />
      </div>
    </div>
  );
}

export default function Dashboard({ tasks, onOpenCmd }) {
  const stats = useMemo(() => {
    const total = tasks.length;
    const done  = tasks.filter(t => t.status === 'done').length;
    const inProg = tasks.filter(t => t.status === 'in-progress').length;
    const todo  = tasks.filter(t => t.status === 'todo').length;
    const high  = tasks.filter(t => t.priority === 'high' && t.status !== 'done').length;
    const overdue = tasks.filter(t => {
      if (!t.due_date || t.status === 'done') return false;
      return new Date(t.due_date) < new Date();
    }).length;
    const pct = total ? Math.round((done / total) * 100) : 0;
    return { total, done, inProg, todo, high, overdue, pct };
  }, [tasks]);

  const recent = useMemo(() =>
    [...tasks].sort((a, b) => new Date(b.created_at) - new Date(a.created_at)).slice(0, 5),
  [tasks]);

  // Simple 7-day activity (mock based on tasks)
  const days = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
  const activity = days.map((d, i) => ({ day: d, count: Math.max(0, Math.floor(Math.random() * 5) - (i % 3)) }));

  return (
    <div className={styles.page}>
      <div className={styles.topRow}>
        <div>
          <h1 className={styles.heading}>Good morning ✦</h1>
          <p className={styles.sub}>Here's your productivity overview</p>
        </div>
        <button className={styles.cmdBtn} onClick={onOpenCmd}>
          <span>⌘</span> Ask AI anything
        </button>
      </div>

      {/* Stat cards */}
      <div className={styles.statsGrid}>
        <StatCard label="Total tasks"     value={stats.total}  color="var(--text-primary)" />
        <StatCard label="Completed"       value={stats.done}   sub={`${stats.pct}% done`}  color="var(--green)" />
        <StatCard label="In progress"     value={stats.inProg} color="var(--blue)" />
        <StatCard label="High priority"   value={stats.high}   color="var(--red)" />
        {stats.overdue > 0 &&
          <StatCard label="Overdue" value={stats.overdue} color="var(--red)" sub="Need attention" />}
      </div>

      <div className={styles.middle}>
        {/* Progress ring */}
        <div className={styles.card}>
          <h2 className={styles.cardTitle}>Completion</h2>
          <div className={styles.ringWrap}>
            <svg viewBox="0 0 120 120" className={styles.ring}>
              <circle cx="60" cy="60" r="50" fill="none" stroke="var(--bg-hover)" strokeWidth="10"/>
              <circle
                cx="60" cy="60" r="50" fill="none"
                stroke="var(--accent)" strokeWidth="10"
                strokeLinecap="round"
                strokeDasharray={`${stats.pct * 3.14} 314`}
                strokeDashoffset="78.5"
                style={{ transition: 'stroke-dasharray 0.6s ease' }}
              />
            </svg>
            <div className={styles.ringCenter}>
              <span className={styles.ringPct}>{stats.pct}%</span>
              <span className={styles.ringLabel}>done</span>
            </div>
          </div>
          <div className={styles.ringBreakdown}>
            <MiniBar label="Todo"        count={stats.todo}   total={stats.total} color="var(--text-muted)" />
            <MiniBar label="In progress" count={stats.inProg} total={stats.total} color="var(--blue)" />
            <MiniBar label="Done"        count={stats.done}   total={stats.total} color="var(--green)" />
          </div>
        </div>

        {/* Activity */}
        <div className={styles.card}>
          <h2 className={styles.cardTitle}>This week</h2>
          <div className={styles.activityChart}>
            {activity.map(({ day, count }) => (
              <div key={day} className={styles.activityCol}>
                <div className={styles.activityBarWrap}>
                  <div
                    className={styles.activityBar}
                    style={{ height: `${Math.max(4, count * 18)}px` }}
                  />
                </div>
                <span className={styles.activityDay}>{day}</span>
              </div>
            ))}
          </div>
          <p className={styles.activityNote}>Tasks completed per day</p>
        </div>

        {/* Recent tasks */}
        <div className={`${styles.card} ${styles.recentCard}`}>
          <h2 className={styles.cardTitle}>Recent tasks</h2>
          <div className={styles.recentList}>
            {recent.length === 0 && (
              <p className={styles.emptyNote}>No tasks yet. Use ⌘K to create one with AI.</p>
            )}
            {recent.map(task => (
              <div key={task.id} className={styles.recentItem}>
                <span
                  className={styles.recentDot}
                  style={{ background: STATUS_COLOR[task.status] || 'var(--text-muted)' }}
                />
                <span className={styles.recentTitle}>{task.title}</span>
                <span
                  className={styles.recentPriority}
                  style={{ color: PRIORITY_COLOR[task.priority] }}
                >
                  {task.priority}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
