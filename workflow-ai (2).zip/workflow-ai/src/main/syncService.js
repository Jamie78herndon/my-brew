const Store = require('electron-store');
const store = new Store();

let syncStatus = {
  provider: null,
  connected: false,
  lastSync: null,
  syncing: false,
};

function getStatus() {
  return {
    ...syncStatus,
    provider: store.get('sync_provider', null),
    connected: store.get('sync_connected', false),
    lastSync: store.get('sync_last', null),
  };
}

async function connect(provider) {
  // In a real implementation, this would open an OAuth flow.
  // For the scaffold we store the selection and mark as connected.
  store.set('sync_provider', provider);
  store.set('sync_connected', true);
  store.set('sync_last', new Date().toISOString());
  syncStatus = { provider, connected: true, lastSync: new Date().toISOString(), syncing: false };
  return { success: true, provider };
}

async function syncNow(data) {
  const connected = store.get('sync_connected', false);
  if (!connected) return { error: 'Not connected to any sync provider' };
  // Placeholder for actual sync logic
  store.set('sync_last', new Date().toISOString());
  return { success: true, timestamp: new Date().toISOString() };
}

module.exports = { getStatus, connect, syncNow };
