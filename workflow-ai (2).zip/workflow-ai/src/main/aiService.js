const Store = require('electron-store');
const store = new Store();

/**
 * Processes a natural language command using the Claude API.
 * Returns a structured action object that the renderer can execute.
 */
async function processCommand(command, context = {}) {
  const apiKey = store.get('anthropic_api_key');
  if (!apiKey) {
    return { error: 'No API key configured. Please add your Anthropic API key in Settings.' };
  }

  const systemPrompt = `You are the AI assistant inside WorkFlow AI, a productivity desktop app.
The user will give you a natural language command. You must respond with ONLY a valid JSON object describing what action to take. No prose, no markdown.

Available action types:
- create_task: { type, title, description?, priority?, due_date?, tags? }
- update_task: { type, id, updates: { title?, status?, priority?, due_date?, tags?, description? } }
- delete_task: { type, id }
- filter_tasks: { type, filter: { status?, priority?, tag?, search? } }
- organize_files: { type, strategy: "by_type" | "by_date" | "by_size" }
- open_file: { type, path }
- show_stats: { type }
- unknown: { type, message: "explanation" }

Current context:
- Tasks count: ${context.taskCount || 0}
- Current view: ${context.view || 'dashboard'}
- Today's date: ${new Date().toISOString().split('T')[0]}

Examples:
- "add a task to review the Q3 report by Friday high priority" → create_task
- "mark the report task as done" → update_task
- "show me all urgent tasks" → filter_tasks
- "organize my downloads by file type" → organize_files`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 512,
        system: systemPrompt,
        messages: [{ role: 'user', content: command }],
      }),
    });

    if (!response.ok) {
      const err = await response.json();
      return { error: err.error?.message || 'API request failed' };
    }

    const data = await response.json();
    const text = data.content[0]?.text || '{}';

    try {
      return JSON.parse(text.replace(/```json|```/g, '').trim());
    } catch {
      return { type: 'unknown', message: 'Could not parse AI response. Please try rephrasing.' };
    }
  } catch (err) {
    return { error: `Network error: ${err.message}` };
  }
}

module.exports = { processCommand };
