const Database = require('better-sqlite3');
const path = require('path');
const { app } = require('electron');
const { v4: uuidv4 } = require('uuid');

const dbPath = path.join(app.getPath('userData'), 'workflow.db');
const db = new Database(dbPath);

// Enable WAL mode for better performance
db.pragma('journal_mode = WAL');

// Migrations
db.exec(`
  CREATE TABLE IF NOT EXISTS tasks (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT DEFAULT '',
    status TEXT DEFAULT 'todo',
    priority TEXT DEFAULT 'medium',
    due_date TEXT,
    tags TEXT DEFAULT '[]',
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS file_bookmarks (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    path TEXT NOT NULL UNIQUE,
    created_at TEXT DEFAULT (datetime('now'))
  );
`);

// --- Tasks ---
function getAllTasks() {
  const rows = db.prepare('SELECT * FROM tasks ORDER BY created_at DESC').all();
  return rows.map(r => ({ ...r, tags: JSON.parse(r.tags) }));
}

function createTask(task) {
  const id = uuidv4();
  const tags = JSON.stringify(task.tags || []);
  db.prepare(`
    INSERT INTO tasks (id, title, description, status, priority, due_date, tags)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(id, task.title, task.description || '', task.status || 'todo',
         task.priority || 'medium', task.due_date || null, tags);
  return { ...task, id, tags: task.tags || [] };
}

function updateTask(id, updates) {
  const fields = [];
  const values = [];
  for (const [key, val] of Object.entries(updates)) {
    if (key === 'id') continue;
    fields.push(`${key} = ?`);
    values.push(key === 'tags' ? JSON.stringify(val) : val);
  }
  fields.push('updated_at = datetime(\'now\')');
  values.push(id);
  db.prepare(`UPDATE tasks SET ${fields.join(', ')} WHERE id = ?`).run(...values);
  return getAllTasks().find(t => t.id === id);
}

function deleteTask(id) {
  db.prepare('DELETE FROM tasks WHERE id = ?').run(id);
  return { success: true };
}

module.exports = { getAllTasks, createTask, updateTask, deleteTask };
