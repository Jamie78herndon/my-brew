const fs = require('fs');
const path = require('path');
const { shell } = require('electron');

const FILE_TYPE_MAP = {
  Images: ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg', '.heic', '.bmp'],
  Documents: ['.pdf', '.doc', '.docx', '.txt', '.md', '.pages', '.odt'],
  Spreadsheets: ['.xls', '.xlsx', '.csv', '.numbers'],
  Presentations: ['.ppt', '.pptx', '.key'],
  Videos: ['.mp4', '.mov', '.avi', '.mkv', '.webm', '.m4v'],
  Audio: ['.mp3', '.wav', '.flac', '.m4a', '.ogg', '.aac'],
  Archives: ['.zip', '.tar', '.gz', '.rar', '.7z'],
  Code: ['.js', '.ts', '.py', '.java', '.c', '.cpp', '.go', '.rs', '.html', '.css', '.json'],
};

function getFileType(ext) {
  for (const [type, exts] of Object.entries(FILE_TYPE_MAP)) {
    if (exts.includes(ext.toLowerCase())) return type;
  }
  return 'Other';
}

function listDirectory(dirPath) {
  if (!dirPath || !fs.existsSync(dirPath)) return { error: 'Directory not found', items: [] };

  try {
    const entries = fs.readdirSync(dirPath, { withFileTypes: true });
    const items = entries
      .filter(e => !e.name.startsWith('.'))
      .map(e => {
        const fullPath = path.join(dirPath, e.name);
        const isDir = e.isDirectory();
        const ext = isDir ? '' : path.extname(e.name);
        let size = 0;
        let modified = null;
        try {
          const stat = fs.statSync(fullPath);
          size = stat.size;
          modified = stat.mtime.toISOString();
        } catch {}
        return {
          name: e.name,
          path: fullPath,
          isDirectory: isDir,
          extension: ext,
          type: isDir ? 'folder' : getFileType(ext),
          size,
          modified,
        };
      })
      .sort((a, b) => {
        if (a.isDirectory && !b.isDirectory) return -1;
        if (!a.isDirectory && b.isDirectory) return 1;
        return a.name.localeCompare(b.name);
      });

    return { path: dirPath, items };
  } catch (err) {
    return { error: err.message, items: [] };
  }
}

function organizeDirectory(dirPath, strategy = 'by_type') {
  if (!dirPath || !fs.existsSync(dirPath)) return { error: 'Directory not found' };

  const entries = fs.readdirSync(dirPath, { withFileTypes: true });
  const moved = [];

  for (const entry of entries) {
    if (entry.isDirectory() || entry.name.startsWith('.')) continue;
    const srcPath = path.join(dirPath, entry.name);
    const ext = path.extname(entry.name);

    let folderName;
    if (strategy === 'by_type') {
      folderName = getFileType(ext);
    } else if (strategy === 'by_date') {
      const stat = fs.statSync(srcPath);
      const d = stat.mtime;
      folderName = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    } else {
      continue;
    }

    const destDir = path.join(dirPath, folderName);
    if (!fs.existsSync(destDir)) fs.mkdirSync(destDir, { recursive: true });

    const destPath = path.join(destDir, entry.name);
    try {
      fs.renameSync(srcPath, destPath);
      moved.push({ from: srcPath, to: destPath });
    } catch {}
  }

  return { success: true, moved: moved.length, strategy };
}

module.exports = { listDirectory, organizeDirectory };
