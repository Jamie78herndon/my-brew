const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const Store = require('electron-store');

const store = new Store();
const isDev = process.env.NODE_ENV === 'development';

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 900,
    minHeight: 600,
    titleBarStyle: 'hiddenInset',
    vibrancy: 'sidebar',
    trafficLightPosition: { x: 16, y: 16 },
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
    icon: path.join(__dirname, '../../assets/icon.png'),
  });

  if (isDev) {
    mainWindow.loadURL('http://localhost:3000');
    mainWindow.webContents.openDevTools();
  } else {
    mainWindow.loadFile(path.join(__dirname, '../../dist/index.html'));
  }
}

app.whenReady().then(() => {
  createWindow();
  setupIpcHandlers();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});

function setupIpcHandlers() {
  const db = require('./database');
  const fileManager = require('./fileManager');
  const aiService = require('./aiService');
  const syncService = require('./syncService');

  // --- Tasks ---
  ipcMain.handle('tasks:getAll', () => db.getAllTasks());
  ipcMain.handle('tasks:create', (_, task) => db.createTask(task));
  ipcMain.handle('tasks:update', (_, id, updates) => db.updateTask(id, updates));
  ipcMain.handle('tasks:delete', (_, id) => db.deleteTask(id));

  // --- Files ---
  ipcMain.handle('files:list', (_, dirPath) => fileManager.listDirectory(dirPath));
  ipcMain.handle('files:open', (_, filePath) => shell.openPath(filePath));
  ipcMain.handle('files:pickDirectory', async () => {
    const result = await dialog.showOpenDialog(mainWindow, { properties: ['openDirectory'] });
    return result.canceled ? null : result.filePaths[0];
  });
  ipcMain.handle('files:organize', (_, dirPath, strategy) => fileManager.organizeDirectory(dirPath, strategy));

  // --- AI ---
  ipcMain.handle('ai:command', async (_, command, context) => {
    return aiService.processCommand(command, context);
  });

  // --- Settings ---
  ipcMain.handle('settings:get', (_, key) => store.get(key));
  ipcMain.handle('settings:set', (_, key, value) => store.set(key, value));

  // --- Sync ---
  ipcMain.handle('sync:status', () => syncService.getStatus());
  ipcMain.handle('sync:connect', (_, provider) => syncService.connect(provider));
}
