const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  // Tasks
  tasks: {
    getAll: () => ipcRenderer.invoke('tasks:getAll'),
    create: (task) => ipcRenderer.invoke('tasks:create', task),
    update: (id, updates) => ipcRenderer.invoke('tasks:update', id, updates),
    delete: (id) => ipcRenderer.invoke('tasks:delete', id),
  },

  // Files
  files: {
    list: (dirPath) => ipcRenderer.invoke('files:list', dirPath),
    open: (filePath) => ipcRenderer.invoke('files:open', filePath),
    pickDirectory: () => ipcRenderer.invoke('files:pickDirectory'),
    organize: (dirPath, strategy) => ipcRenderer.invoke('files:organize', dirPath, strategy),
  },

  // AI
  ai: {
    command: (command, context) => ipcRenderer.invoke('ai:command', command, context),
  },

  // Settings
  settings: {
    get: (key) => ipcRenderer.invoke('settings:get', key),
    set: (key, value) => ipcRenderer.invoke('settings:set', key, value),
  },

  // Sync
  sync: {
    status: () => ipcRenderer.invoke('sync:status'),
    connect: (provider) => ipcRenderer.invoke('sync:connect', provider),
  },

  // Platform info
  platform: process.platform,
});
