# WorkFlow AI

A cross-platform desktop productivity app built with Electron, React, and the Claude API.

## Features

- **AI natural language commands** — Press `⌘K` (or `Ctrl+K`) and type anything: *"create a high priority task for the Q3 report due Friday"*, *"organize my Downloads by file type"*, *"show all in-progress tasks"*
- **Kanban task board** — Drag & drop cards across Todo / In Progress / Done columns
- **File manager** — Browse any folder, auto-organize files by type or date
- **Dashboard** — Completion stats, activity chart, recent tasks
- **Cloud sync** — Connect Google Drive or Dropbox (OAuth flow)
- **Cross-platform** — macOS, Windows, Linux

## Quick Start

### Prerequisites

- Node.js 18+
- An [Anthropic API key](https://console.anthropic.com)

### Install & run

```bash
npm install
npm run dev
```

The Vite dev server starts on `http://localhost:3000` and Electron loads it automatically.

### Build for production

```bash
npm run build
```

Outputs platform-specific installers to `dist/`.

## Project Structure

```
workflow-ai/
├── src/
│   ├── main/               # Electron main process (Node.js)
│   │   ├── main.js         # App entry, window, IPC handlers
│   │   ├── preload.js      # Secure IPC bridge
│   │   ├── database.js     # SQLite via better-sqlite3
│   │   ├── aiService.js    # Claude API integration
│   │   ├── fileManager.js  # File system operations
│   │   └── syncService.js  # Cloud sync (Google Drive / Dropbox)
│   └── renderer/           # React frontend
│       ├── App.jsx          # Root layout + routing + AI action dispatch
│       ├── components/
│       │   ├── Sidebar.jsx      # Navigation
│       │   ├── TitleBar.jsx     # macOS-style drag region
│       │   └── CommandBar.jsx   # ⌘K AI command input
│       └── pages/
│           ├── Dashboard.jsx    # Stats + charts
│           ├── Tasks.jsx        # Kanban board
│           ├── Files.jsx        # File browser
│           └── Settings.jsx     # API key + sync config
├── assets/                 # App icon etc.
├── vite.config.js
└── package.json
```

## Configuration

Open the app → Settings and enter your Anthropic API key. That's it — all AI commands go through the Claude API.

## AI Commands

| Example phrase | What it does |
|---|---|
| `add a task to review the Q3 report` | Creates a new task |
| `mark the design task as done` | Updates task status |
| `show all high priority tasks` | Filters the task board |
| `organize my downloads by file type` | Groups files into folders |
| `show my stats` | Opens Dashboard |

## Tech Stack

| Layer | Technology |
|---|---|
| Desktop shell | Electron 29 |
| Frontend | React 18 + Vite |
| Styling | CSS Modules |
| Database | SQLite (better-sqlite3) |
| AI | Claude API (claude-sonnet-4) |
| Cloud sync | Google Drive SDK / Dropbox SDK |

## Extending the App

- **Add more AI actions**: Edit `aiService.js` system prompt and add cases in `App.jsx → handleAIAction`
- **More views**: Add a new page in `src/renderer/pages/` and register it in `App.jsx`
- **Real OAuth sync**: Implement the full OAuth flow in `syncService.js` using the googleapis / dropbox packages
